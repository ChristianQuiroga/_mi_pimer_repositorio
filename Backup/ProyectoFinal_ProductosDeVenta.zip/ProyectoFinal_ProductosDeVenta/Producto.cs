﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal_ProductosDeVenta
{
    internal class Producto
    {

        #region Atributos
        private int _id;
        private string? _descripcion;
        private double _costo;
        private double _precioVenta;
        private int _stock;
        private int _idUsuario;
        #endregion


        #region Propiedades
        public int Id { get => _id; set => _id = value; }
        public string? Descripcion { get => _descripcion; set => _descripcion = value; }
        public double Costo { get => _costo; set => _costo = value; }
        public double PrecioVenta { get => _precioVenta; set => _precioVenta = value; }
        public int Stock { get => _stock; set => _stock = value; }
        public int IdUsuario { get => _idUsuario; set => _idUsuario = value; }
        #endregion



        #region Contructores
        //parámetros
        public Producto(int id, string descripcion, double costo, double precioVenta, int stock, int idUsuario)
        {
            this.Id = id;
            this.Descripcion = descripcion;
            this.Costo = costo;
            this.PrecioVenta = precioVenta;
            this.Stock = stock;
            this.IdUsuario = idUsuario;
        }
        //por defecto
        public Producto()
        {
            this.Id = 0;
            this.Descripcion = string.Empty;
            this.Costo = 0.00d;
            this.PrecioVenta = 0.00D;
            this.Stock = 0;
            this.IdUsuario = 0;
        }
        #endregion


    }
}
